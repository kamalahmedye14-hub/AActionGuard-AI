# ActionGuard AI — MVP 0.1

An early, locally runnable prototype for AI-agent action authorization and sensitive-data scanning.

## Features
- English, Arabic (RTL), and Simplified Chinese interface.
- Express API with server-side pattern scanning.
- Deterministic decisions: BLOCK credential-like tokens, REDACT detected personal data, and REVIEW text with no matching rule (manual review; no automatic allow).
- Read-only demo action authorization gate.
- SQLite audit log that stores decisions/rules, not submitted text.
- Automated unit tests.

## Requirements
Node.js 20+ and npm.

## Run locally
```bash
npm install
npm run dev
```
Frontend: http://localhost:5173  
API: http://localhost:4000/api/health

## Run tests
```bash
npm test
```

## Build frontend
```bash
npm run build
```

## Important security limitations
This is an MVP demonstration, not a production security product.
- No user authentication, tenant isolation, RBAC, CSRF protection, or production deployment hardening yet. A basic in-memory per-IP request throttle is included, but it is not suitable as a distributed production control.
- The action gate authorizes a harmless read-only demo permission; it does not execute external tools or intercept third-party AI traffic.
- Pattern matching is heuristic and cannot prove whether a credential is genuine.
- The scanner supports illustrative credential-like strings, email addresses, and broad phone-like patterns; false positives/negatives are possible.
- `REVIEW` is returned for unknown actions, but approval workflow is not implemented yet.
- Use only synthetic test data. Do not submit real secrets or personal information.
- Before internet exposure, add authentication, authorization, tenant isolation, TLS, rate limits, secure headers, secret management, and security review.

## Suggested next steps
1. Add authentication and per-tenant ownership.
2. Move policies into an admin-managed schema with tested precedence.
3. Implement explicit human approval for REVIEW.
4. Integrate one real tool through a server-side adapter and prove denied actions never execute.
5. Add integration tests and deployment hardening.


## Product direction

ActionGuard AI is a single security product for organizations. This repository does not include subscription tiers, pricing pages, payment processing, or billing.

## Security status and limitations

This is an MVP/demo, not a production security gateway. The scanner uses heuristic regular expressions and can miss secrets or produce false positives. The API currently has no user authentication, organization/tenant isolation, role-based access control, or durable distributed rate limiting. Audit and policy endpoints must not be exposed to untrusted networks until authentication and tenant authorization are implemented. The in-memory request throttle is a basic development safeguard and resets when the server restarts.

Use synthetic test data only. Do not submit real customer records, credentials, API keys, or confidential company information.
