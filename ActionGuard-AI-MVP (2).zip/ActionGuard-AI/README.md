# ActionGuard AI — MVP 0.1

An early, locally runnable prototype for AI-agent action authorization and sensitive-data scanning.

## Features
- English, Arabic (RTL), and Simplified Chinese interface.
- Express API with server-side pattern scanning.
- Deterministic decisions: ALLOW, BLOCK, REDACT, REVIEW.
- Read-only demo action authorization gate.
- SQLite audit log that stores decisions/rules, not submitted text.
- Automated unit tests.

## Requirements
Node.js 20+ and npm.

## Run locally
```bash
npm install
npm run dev
```
Frontend: http://localhost:5173  
API: http://localhost:4000/api/health

## Run tests
```bash
npm test
```

## Build frontend
```bash
npm run build
```

## Important security limitations
This is an MVP demonstration, not a production security product.
- No user authentication, tenant isolation, RBAC, CSRF protection, rate limiting, or production deployment hardening yet.
- The action gate authorizes a harmless read-only demo permission; it does not execute external tools or intercept third-party AI traffic.
- Pattern matching is heuristic and cannot prove whether a credential is genuine.
- The scanner supports illustrative credential-like strings, email addresses, and broad phone-like patterns; false positives/negatives are possible.
- `REVIEW` is returned for unknown actions, but approval workflow is not implemented yet.
- Use only synthetic test data. Do not submit real secrets or personal information.
- Before internet exposure, add authentication, authorization, tenant isolation, TLS, rate limits, secure headers, secret management, and security review.

## Suggested next steps
1. Add authentication and per-tenant ownership.
2. Move policies into an admin-managed schema with tested precedence.
3. Implement explicit human approval for REVIEW.
4. Integrate one real tool through a server-side adapter and prove denied actions never execute.
5. Add integration tests and deployment hardening.
