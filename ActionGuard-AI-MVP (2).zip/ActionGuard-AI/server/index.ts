import express from 'express';
import cors from 'cors';
import { z } from 'zod';
import { db } from './db';
import { scanSensitiveText, decideScan, redactText, authorizeAction } from './security';
const app=express();
app.use(cors({origin:process.env.CORS_ORIGIN?.split(',')??true}));
app.use(express.json({limit:'32kb'}));
function audit(event:string,outcome:string,rule:string){db.prepare('INSERT INTO audit_events(event,outcome,rule) VALUES(?,?,?)').run(event,outcome,rule);}
app.get('/api/health',(_req,res)=>res.json({ok:true,service:'ActionGuard AI API',version:'0.1.0'}));
app.get('/api/audit',(_req,res)=>res.json(db.prepare('SELECT * FROM audit_events ORDER BY id DESC LIMIT 50').all()));
app.get('/api/policies',(_req,res)=>res.json(db.prepare('SELECT id,name,action,priority,enabled FROM policies ORDER BY priority ASC').all()));
app.post('/api/scan',(req,res)=>{
 const parsed=z.object({text:z.string().min(1).max(12000)}).safeParse(req.body);
 if(!parsed.success)return res.status(400).json({error:'Text must be between 1 and 12000 characters'});
 const findings=scanSensitiveText(parsed.data.text);
 const decision=decideScan(findings);
 const safeText=decision==='REDACT'?redactText(parsed.data.text,findings):undefined;
 const rule=decision==='ALLOW'?'No matching sensitive pattern':decision==='BLOCK'?'Credential pattern detected':'Sensitive personal-data pattern detected';
 audit('DATA_SCAN',decision,rule);
 res.json({decision,findings:findings.map(({type,severity,masked})=>({type,severity,masked})),safeText,policy:rule});
});
app.post('/api/authorize-action',(req,res)=>{
 const parsed=z.object({agent:z.string().min(1).max(100),action:z.string().min(1).max(100),resource:z.string().min(1).max(200)}).safeParse(req.body);
 if(!parsed.success)return res.status(400).json({error:'Invalid action request'});
 const result=authorizeAction(parsed.data.action,parsed.data.resource);
 audit('AGENT_ACTION_CHECK',result.decision,result.reason);
 res.json({...result,agent:parsed.data.agent});
});
const port=Number(process.env.PORT||4000);
app.listen(port,'0.0.0.0',()=>console.log(`ActionGuard API listening on ${port}`));
